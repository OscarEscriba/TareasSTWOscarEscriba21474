function Sidebar(props) {
    return (
      <aside style={{ height: "100vh", width: "100px", backgroundColor: "blue" }}>
        {props.text}
      </aside>
    );
  }

